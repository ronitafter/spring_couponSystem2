package com.ronit.enums;

public enum ClientType {
	ADMINISTRATOR, COMPANY, CUSTOMER;

}
