package com.ronit.services;

import java.util.Optional;

public class Test {

//	public static void main(String[] args) {
//		
//		Optional<String> opt = Optional.of("aaa");
////		Optional<String> opt = Optional.empty();
//		
//		System.out.println(opt.isPresent());
//		System.out.println(opt.isEmpty());
//		
//		String str = opt.get();
//		System.out.println(str);
//
//	}

}
